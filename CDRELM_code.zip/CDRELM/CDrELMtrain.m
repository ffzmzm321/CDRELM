function [IW,B,LW,TF,TYPE] = CDrELMtrain(P,T,N,TF,TYPE)
% CDRELMTRAIN Create and Train a Double regularized Extreme Learning Machine based on C�Closs

% Syntax
% [IW,B,LW,TF,TYPE] = CDrelmtrain(P,T,N,TF,TYPE)
% Description
% Input
% P   - Input Matrix of Training Set  (R*Q)
% T   - Output Matrix of Training Set (S*Q)
% N   - Number of Hidden Neurons (default = Q)
% TF  - Transfer Function:
%       'sig' for Sigmoidal function (default)
%       'sin' for Sine function
%       'hardlim' for Hardlim function
% TYPE - Regression (0,default) or Classification (1)
% Output
% IW  - Input Weight Matrix (N*R)
% B   - Bias Matrix  (N*1)
% LW  - Layer Weight Matrix (N*S)
% Example
% Regression:
% [IW,B,LW,TF,TYPE] = elmtrain(P,T,20,'sig',0)
% Y = elmtrain(P,IW,B,LW,TF,TYPE)
% Classification
% [IW,B,LW,TF,TYPE] = elmtrain(P,T,20,'sig',1)
% Y = elmtrain(P,IW,B,LW,TF,TYPE)
% author: fuyanlin
if nargin < 2
    error('ELM:Arguments','Not enough input arguments.');
end
if nargin < 3
    N = size(P,2);
end
if nargin < 4
    TF = 'sig';
end
if nargin < 5
    TYPE = 0;
end
if size(P,2) ~= size(T,2)
    error('ELM:Arguments','The columns of P and T must be same.');
end
[R,Q] = size(P);
if TYPE  == 1
    T  = ind2vec(T);
end
[S,Q] = size(T);
% Randomly Generate the Input Weight Matrix
IW = rand(N,R) * 2 - 1;
% Randomly Generate the Bias Matrix
B = rand(N,1);
BiasMatrix = repmat(B,1,Q);
% Calculate the Layer Output Matrix H
tempH = IW * P + BiasMatrix;
switch TF
    case 'sig'
        H = 1 ./ (1 + exp(-tempH));
    case 'sin'
        H = sin(tempH);
    case 'hardlim'
        H = hardlim(tempH);
end
% Calculate the Output Weight Matrix
tic;
LW = pinv(H') * T';
gamma_max = norm(H*T','inf');
gamma = 0.1*gamma_max;

% cached computations for all methods
AtA = H*H';
Atb = H*T';
MAX_ITER = 100;
ABSTOL   = 1e-4;
RELTOL   = 1e-2;

% % improved proximal gradient descent algorithm
f = @(LW) 0.5*sum_square(LW'*H-T); 
lambda = 1;
beta = 0.5;
tic;
xprev = LW;
for k = 1:MAX_ITER
    while 1
        grad_x = AtA*LW - Atb;
        z = soft_threshold(LW - lambda*grad_x, lambda*gamma);%%��������x
        if f(z) <= f(LW) + grad_x'*(z - LW) + (1/(2*lambda))*(norm(z - LW))^2
            break;
        end
        lambda = beta*lambda;
    end
    xprev = LW;
    LW = z;
       h.prox_optval(k) = objective(H, T,LW);
    if k > 1 && abs(h.prox_optval(k) - h.prox_optval(k-1)) < ABSTOL
        break;
    end
end
h.x_prox = LW;
h.p_prox = h.prox_optval(end);
h.prox_grad_toc = toc;
function p = objective(H,T,LW) %the CDRELM  
  p = 1-exp(-(sum_square(LW'*H - T))/2*(2.^(-2))) + 2^(-10)*norm(LW,1)+2^(-34)*norm(LW,2);
end
 
function [X]=soft_threshold(T,lambda)
  X=sign(T).*max(abs(T) - lambda,0);
end
end