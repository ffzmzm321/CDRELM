%% CDRELM for regression
%  NIR          - datasets include all the features
%  ocane        - datasets include targets 
%  P_train      - training data
%  T_train      - training targets
%  P_test       - testing data
%  T_test       - testing targets
%  Author: Fuyanlin
% Datetime:2021-11-02
clear all
clc
tic


%% datasets sinc
NIR=xlsread('sinc1.xls','Sheet1','A2:A2002');
octane=xlsread('sinc1.xls','Sheet1','B2:B2002');
% 
temp = randperm(size(NIR,1));
% train samples
P_train = NIR(temp(1:1500),:)';   
T_train = octane(temp(1:1500),:)';
% test samples
P_test = NIR(temp(1501:2001),:)';
T_test = octane(temp(1501:2001),:)';
N = size(P_test,2);
K=10;
%% data normalization

% train 
[Pn_train,inputps] = mapminmax(P_train);
Pn_test = mapminmax('apply',P_test,inputps);
% test
[Tn_train,outputps] = mapminmax(T_train);
Tn_test =  mapminmax('apply',T_test,outputps);

%% train samples with CDRELM 
[IW1,B1,LW1,TF,TYPE] = elmtrain(Pn_train,Tn_train,30,'sin',0);
[IW2,B2,LW2,TF,TYPE] = CELMtrain(Pn_train,Tn_train,30,'sin',0);
[IW3,B3,LW3,TF,TYPE] = RELMtrain(Pn_train,Tn_train,30,'sin',0);
[IW4,B4,LW4,TF,TYPE] = CDrELMtrain(Pn_train,Tn_train,30,'sin',0);

%% predict samples with CDRELM 
tn_sim1 = elmpredict(Pn_test,IW1,B1,LW1,TF,TYPE);
tn_sim2 = elmpredict(Pn_test,IW2,B2,LW2,TF,TYPE);
tn_sim3 = elmpredict(Pn_test,IW3,B3,LW3,TF,TYPE);
tn_sim4 = elmpredict(Pn_test,IW4,B4,LW4,TF,TYPE);
% ����һ��
T_sim1 = mapminmax('reverse',tn_sim1,outputps);
T_sim2 = mapminmax('reverse',tn_sim2,outputps);
T_sim3 = mapminmax('reverse',tn_sim3,outputps);
T_sim4 = mapminmax('reverse',tn_sim4,outputps);

%% result 
result = [T_test' T_sim1'];
result = [T_test' T_sim2'];
result = [T_test' T_sim3'];
result = [T_test' T_sim4'];
% mse
E1 = mse(T_sim1 - T_test)
E2 = mse(T_sim2 - T_test)
E3 = mse(T_sim3 - T_test)
E4 = mse(T_sim4 - T_test)

% R^2
N = length(T_test);
R21=(N*sum(T_sim1.*T_test)-sum(T_sim1)*sum(T_test))^2/((N*sum((T_sim1).^2)-(sum(T_sim1))^2)*(N*sum((T_test).^2)-(sum(T_test))^2)) 
R22=(N*sum(T_sim2.*T_test)-sum(T_sim2)*sum(T_test))^2/((N*sum((T_sim2).^2)-(sum(T_sim2))^2)*(N*sum((T_test).^2)-(sum(T_test))^2))
R23=(N*sum(T_sim3.*T_test)-sum(T_sim3)*sum(T_test))^2/((N*sum((T_sim3).^2)-(sum(T_sim3))^2)*(N*sum((T_test).^2)-(sum(T_test))^2))
R24=(N*sum(T_sim4.*T_test)-sum(T_sim4)*sum(T_test))^2/((N*sum((T_sim4).^2)-(sum(T_sim4))^2)*(N*sum((T_test).^2)-(sum(T_test))^2))
%% figure 
figure
plot(P_test,T_test,'bo',P_test,T_sim1,'r*',P_test,T_sim2,'g*',P_test,T_sim3,'y*',P_test,T_sim4,'k*')
grid on
legend('True','ELM','CELM','RELM','CDRELM')
xlabel('Inputs')
ylabel('Outputs')
string = {'Comparison of  prediction in SinC test set'};
title(string)
toc

figure
plot(1:length(T_test),T_test-T_sim1,'r-*')
hold on
plot(1:length(T_test),T_test-T_sim2,'g-*')
hold on
plot(1:length(T_test),T_test-T_sim3,'y-*')
hold on
plot(1:length(T_test),T_test-T_sim4,'k-*')
xlabel('Number of test datasets')
ylabel('MSE')
title('Comparison of MSE in sinC test set')
legend('ELM','CELM','RELM','CDRELM')